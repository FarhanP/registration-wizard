import React from "react";

const NavigationButtons = ({ step, onNext, onPrevious }) => {
  console.log("Step check", step);
  return (
    <div className="navigation-buttons">
      {step > 1 && (
        <button className="btn btn-secondary" onClick={onPrevious}>
          Previous
        </button>
      )}
      <button className="btn btn-primary" onClick={onNext}>
        {step === 2 ? "Submit" : "Next"}
      </button>
    </div>
  );
};

export default NavigationButtons;
