import React from "react";

const InputField = ({ label, name, type, register, validation, error }) => {
  console.log("valiadtion test", validation);
  return (
    <div className="input-field">
      <label htmlFor={name}>{label}</label>
      <input
        id={name}
        name={name}
        type={type}
        {...register(name, validation)}
      />
      {error && <p className="error">{error.message}</p>}
    </div>
  );
};

export default InputField;
