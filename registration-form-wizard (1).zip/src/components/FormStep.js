import React from "react";
import InputField from "./InputField";

const FormStep = ({ title, fields, errors, register }) => {
  return (
    <div className="form-step">
      <h2>{title}</h2>
      {fields.map((field) => (
        <InputField
          key={field.name}
          {...field}
          error={errors[field.name]}
          register={register}
        />
      ))}
    </div>
  );
};

export default FormStep;
