## Registration Wizard App

# Intro
> A multi-step registration form built using React. It includes validation, step navigation, and a mock API to submit the registration data. 


# API
The app uses a mock API to simulate the form submission. You can use this link (https://673a564d339a4ce44517e8ed.mockapi.io/api/registrationwizard/data) to view the API data you post submission
