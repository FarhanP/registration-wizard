import React, { useState } from "react";
import { useForm } from "react-hook-form";
import FormStep from "../components/FormStep";
import NavigationButtons from "../components/NavigationButtons";
import "../styles.css";

const RegistrationWizard = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({});
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();

  const nextStep = (data) => {
    setFormData({ ...formData, ...data });
    setStep((prev) => Math.min(prev + 1, 2));
  };

  const prevStep = () => setStep((prev) => Math.max(prev - 1, 1));

  const onSubmit = async (data) => {
    const finalData = { ...formData, ...data };
    try {
      const response = await fetch(
        "https://673a564d339a4ce44517e8ed.mockapi.io/api/registrationwizard/data",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(finalData),
        }
      );
      if (response.ok) {
        alert("Registration successful!");
        reset(); // resetting the form
        setFormData({}); // reset formData
        setStep(1);
      } else {
        throw new Error("Submission failed.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred during registration.");
    }
  };

  const validatePassword = (value) =>
    value.length >= 6 || "Password must be at least 6 characters long";

  return (
    <div className="wizard-container">
      <h1>Multi-Step Registration Wizard</h1>
      {step === 1 && (
        <form onSubmit={handleSubmit(nextStep)}>
          <FormStep
            title="Step 1: Account Details"
            fields={[
              {
                name: "username",
                label: "Username",
                type: "text",
                validation: {
                  required: "Username is required",
                  minLength: {
                    value: 3,
                    message: "Username must be at least 3 characters",
                  },
                },
              },
              {
                name: "password",
                label: "Password",
                type: "password",
                validation: {
                  required: "Password is required",
                  validate: validatePassword,
                },
              },
            ]}
            errors={errors}
            register={register}
          />
          <NavigationButtons onNext={handleSubmit(nextStep)} />
        </form>
      )}
      {step === 2 && (
        <form onSubmit={handleSubmit(onSubmit)}>
          <FormStep
            title="Step 2: Address Information"
            fields={[
              {
                name: "address",
                label: "Address",
                type: "text",
                validation: { required: "Address is required" },
              },
              {
                name: "city",
                label: "City",
                type: "text",
                validation: { required: "City is required" },
              },
              {
                name: "zip",
                label: "Zip Code",
                type: "text",
                validation: {
                  required: "Zip code is required",
                  pattern: {
                    value: /^[0-9]{5}$/,
                    message: "Enter a valid 5-digit zip code",
                  },
                },
              },
            ]}
            errors={errors}
            register={register}
          />
          <NavigationButtons
            onPrevious={prevStep}
            step={step}
            onNext={handleSubmit(onSubmit)}
          />
        </form>
      )}
    </div>
  );
};

export default RegistrationWizard;
