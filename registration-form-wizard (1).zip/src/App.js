import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import RegistrationWizard from "./components/RegistrationWizard";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <StrictMode>
    <RegistrationWizard />
    <h5 className="author-name">Made with &#9825; by Farhan</h5>
  </StrictMode>
);
